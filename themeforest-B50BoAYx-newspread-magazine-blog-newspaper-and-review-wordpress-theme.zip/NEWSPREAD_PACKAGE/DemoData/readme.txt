Demo Data is installed directly within the theme itself, please see:
https://commercegurus.freshdesk.com/solution/folders/12000007463
