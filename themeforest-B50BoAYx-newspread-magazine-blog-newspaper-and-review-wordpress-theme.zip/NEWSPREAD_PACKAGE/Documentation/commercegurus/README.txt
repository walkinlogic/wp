Theme docs are now available online!

Please visit 
https://commercegurus.freshdesk.com/solution/folders/12000007463
