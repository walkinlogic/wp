import { combineReducers } from "redux";
import settings from "./settings/Reducer";

const Reducers = combineReducers({
  settings,
});

export default Reducers;
