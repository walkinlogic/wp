import React from "react";
import {
    Card,
    CardBody,

} from 'reactstrap';

const Dashboard = () => {
    return (
        <Card>
            <CardBody>
                Start your project from here...
				</CardBody>
        </Card >
    );
}

export default Dashboard;