<?php
/**
 * Visit Logs
 *
 * @package     ElleLogs
 * @author      Haroon Abbas
 * @copyright   2021 Haroon Abbas
 * @license     GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name: Visit Logs
 * Plugin URI:  https://www.elle.com.sg/
 * Description: This plugin prints "Visit Logs" inside an admin page.
 * Version:     1.0.0
 * Author:      Haroon Abbas
 * Author URI:  https://www.elle.com.sg/
 * Text Domain: visit-logs
 * License:     GPL v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */
 function create_plugin_database_table()
{
    global $table_prefix, $wpdb;

    $tblname = 'ip_log';
    $wp_track_table = $table_prefix . $tblname;
 

    if($wpdb->get_var( "show tables like '$wp_track_table'" ) != $wp_track_table) 
    {

        $sql = "CREATE TABLE `". $wp_track_table . "`  (
			  `log_id` int(11) NOT NULL,
			  `remote_addr` varchar(255) NOT NULL DEFAULT '',
			  `server_addr` varchar(255) NOT NULL DEFAULT '',
			  `user_agent` varchar(255) NOT NULL DEFAULT '',
			  `request_uri` varchar(255) NOT NULL DEFAULT '',
			  `message` text NOT NULL,
			  `log_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
			  `status` int(11) NOT NULL DEFAULT '0'
			) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;";
        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }
}
register_activation_hook( __FILE__, 'create_plugin_database_table' );
function display_elle_logs_page() {
  global $table_prefix,$wpdb; 
	if(isset($_GET['action']) && isset($_GET['logid'])){
		$htaccessFile = '/var/www/html/.htaccess';
		chmod($htaccessFile, 0755);
		$htaccessContent = file_get_contents($htaccessFile);
		$ip=base64_decode($_GET['logid']);
		if($_GET['action']==1){
			$htaccessContent .="\n\t";
			$htaccessContent .='Deny from '.$ip; 
			$r = file_put_contents($htaccessFile,$htaccessContent); 
		}else{
			 
			$htaccessContent = str_replace('Deny from '.$ip,'', $htaccessContent);
			$r = file_put_contents($htaccessFile,$htaccessContent);   
		}
		 			
		$sql = "UPDATE ".$table_prefix."ip_log SET status=".$wpdb->_escape($_GET['action'])." WHERE remote_addr = '".base64_decode($wpdb->_escape($_GET['logid']))."'"; 
		$wpdb->query($sql);
		echo '<script>window.location.href = "/wp-admin/admin.php?page=visit-logs";</script>';	 
		exit;
	} 
  
	if (isset($_GET['page_no']) && $_GET['page_no']!="") {
		$page_no = $_GET['page_no'];
	} else {
		$page_no = 1;
	}
	$total_records_per_page = 1000;
    $offset = ($page_no-1) * $total_records_per_page;
	$previous_page = $page_no - 1;
	$next_page = $page_no + 1;
	$adjacents = "10"; 
	
	$total_records = $wpdb->get_var("SELECT COUNT(DISTINCT CONCAT(remote_addr, request_uri)) FROM  ".$table_prefix."ip_log ");
	$total_no_of_pages = ceil($total_records / $total_records_per_page);
	$second_last = $total_no_of_pages - 1;  
	$sql="";
	if ( ! empty( $_REQUEST['orderby'] ) ) {
		if($_REQUEST['orderby']=='total_visit'){
			$sql .= ' ORDER BY count(log_id) ';
		}else{
			$sql .= ' ORDER BY ' . esc_sql( $_REQUEST['orderby'] );
		}
		
		$sql .= ! empty( $_REQUEST['order'] ) ? ' ' . esc_sql( $_REQUEST['order'] ) : ' ASC';
	}else{
		$sql="ORDER BY  convert(log_date,DATE) desc,count(log_id) desc ";
	}
  
	$results = $wpdb->get_results("SELECT remote_addr,request_uri, server_addr, user_agent, status, convert(log_date,DATE) log_date, count(log_id) as totalvisit FROM ".$table_prefix."ip_log  GROUP BY remote_addr, request_uri  ".$sql." LIMIT ".$offset.", ".$total_records_per_page);
	
	?>
	<h3> Traffic Dashboard -  IVT/GIVT/BOTS MANAGER  </h3>
	<style>
		.paginationbtn a.button{margin:0px 5px;}
	</style>
	 
	<table class="wp-list-table widefat fixed striped table-view-list posts" width="100%">
		<thead>
			<tr>
				<th>ID</th>
				<th>REMOTE ADDR</th>
				<th>SERVER ADDR</th> 
				<th>REQUEST URI</th>
				<th>USER AGENT</th>
				<th scope="col" id="title" class="manage-column column-title column-primary <?php if(isset($_REQUEST['orderby']) && $_REQUEST['orderby']=='log_date'){?>sorted  <?php  echo $_REQUEST['order'];?> <?php } ?>"><a href="https://www.elle.com.sg/wp-admin/admin.php?page=visit-logs&amp;orderby=log_date&amp;order=<?php echo ($_REQUEST['order']=='asc' ) ? 'desc' : 'asc';?>"><span>Log Date</span><span class="sorting-indicator"></span></a></th>
				<th scope="col" id="title" class="manage-column column-title column-primary <?php if(isset($_REQUEST['orderby']) && $_REQUEST['orderby']=='total_visit'){?>sorted  <?php echo $_REQUEST['order'];?> <?php } ?>"><a href="https://www.elle.com.sg/wp-admin/admin.php?page=visit-logs&amp;orderby=total_visit&amp;order=<?php echo ($_REQUEST['order']=='asc' ) ? 'desc' : 'asc';?>"><span>Total Visit</span><span class="sorting-indicator"></span></a></th>
				 
				<th>Current State</th>
				<?php /* <th>Status</th> */ ?>
			</tr>
		</thead>
		<tbody>
			<?php $counter = $page_no;foreach($results as $result){ ?>
				<tr>
					<td><?php echo $counter++;?></td>
					<td><?php echo $result->remote_addr;?></td>
					<td><?php echo $result->server_addr;?></td> 
					<td><?php echo $result->request_uri;?></td>
					<td><?php echo $result->user_agent;?></td>
					<td><?php echo $result->log_date;?></td>
					<td><?php echo $result->totalvisit;?></td>
					<td><?php echo ($result->status==1?'Block':'Unblock');?></td>
					<?php $state=($result->status==1?0:1);?> 
					<?php $statelbl=($result->status==1?'Unblock':'Block');?>
					<?php /* <td><a class='button button-secondary' disabled href='?page=visit-logs&action=<?php echo $state;?>&logid=<?php echo base64_encode($result->remote_addr);?>'><?php echo $statelbl;?></a></td> */ ?>
				</tr>
			<?php }?>
			
		</tbody>
	</table>
	
	<div style='padding: 10px 20px 0px; border-top: dotted 1px #CCC;'>
		<strong>Page <?php echo $page_no." of ".$total_no_of_pages; ?></strong>
	</div>
	
	<ul class="pagination paginationbtn">
	<?php // if($page_no > 1){ echo "<li><a href='?page=visit-logs&page_no=1'>First Page</a></li>"; } ?>
    
		<li <?php if($page_no <= 1){ echo "class='disabled'"; } ?>>
		<a class='button button-secondary' <?php if($page_no > 1){ echo "href='?page=visit-logs&page_no=$previous_page'"; } ?>>Previous</a>
		</li>
		   
		<?php 
		$extra = '';
		if ( ! empty( $_REQUEST['orderby'] ) ) {
			 $extra='&orderby='.$_REQUEST['orderby'];
			 $extra.='&order='.$_REQUEST['order']; 
		}
		if ($total_no_of_pages <= 10){  	 
			for ($counter = 1; $counter <= $total_no_of_pages; $counter++){
				if ($counter == $page_no) {
			   echo "<li class='active'><a  class='button button-secondary'>$counter</a></li>";	
					}else{
			   echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=$counter".$extra."'>$counter</a></li>";
					}
			}
		}
		elseif($total_no_of_pages > 10){
			
		if($page_no <= 4) {			
		 for ($counter = 1; $counter < 8; $counter++){		 
				if ($counter == $page_no) {
			   echo "<li class='active'><a class='button button-secondary'>$counter</a></li>";	
					}else{
			   echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=$counter".$extra."'>$counter</a></li>";
					}
			}
			echo "<li><a class='button button-secondary'>...</a></li>";
			echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=$second_last".$extra."'>$second_last</a></li>";
			echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=$total_no_of_pages".$extra."'>$total_no_of_pages</a></li>";
			}

		elseif($page_no > 4 && $page_no < $total_no_of_pages - 4) {		 
			echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=1".$extra."'>1</a></li>";
			echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=2".$extra."'>2</a></li>";
			echo "<li><a class='button button-secondary'>...</a></li>";
			for ($counter = $page_no - $adjacents; $counter <= $page_no + $adjacents; $counter++) {			
			   if ($counter == $page_no) {
			   echo "<li class='active'><a class='button button-secondary'>$counter</a></li>";	
					}else{
			   echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=$counter".$extra."'>$counter</a></li>";
					}                  
		   }
		   echo "<li><a class='button button-secondary'>...</a></li>";
		   echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=$second_last".$extra."'>$second_last</a></li>";
		   echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=$total_no_of_pages".$extra."'>$total_no_of_pages</a></li>";      
		}
			
			else {
			echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=1".$extra."'>1</a></li>";
			echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=2".$extra."'>2</a></li>";
			echo "<li><a class='button button-secondary'>...</a></li>";

			for ($counter = $total_no_of_pages - 6; $counter <= $total_no_of_pages; $counter++) {
			  if ($counter == $page_no) {
			   echo "<li class='active'><a class='button button-secondary'>$counter</a></li>";	
					}else{
			   echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=$counter".$extra."'>$counter</a></li>";
					}                   
					}
				}
		}
	?>
		
		<li <?php if($page_no >= $total_no_of_pages){ echo "class='disabled'"; } ?>>
		<a  class='button button-secondary' <?php if($page_no < $total_no_of_pages) { echo "href='?page=visit-logs&page_no=$next_page".$extra."'"; } ?>>Next</a>
		</li>
		<?php if($page_no < $total_no_of_pages){
			echo "<li><a class='button button-secondary' href='?page=visit-logs&page_no=$total_no_of_pages".$extra."'>Last &rsaquo;&rsaquo;</a></li>";
			} ?>
	</ul>
	<?php 
	
}
function elle_logs_admin_menu() {
  add_menu_page(
        'Custom Traffic Log',// page title
        'Custom Traffic Log',// menu title
        'manage_options',// capability
        'visit-logs',// menu slug
        'display_elle_logs_page' // callback function
    );
}
add_action('admin_menu', 'elle_logs_admin_menu');

function log_scripts(){
	
  global $table_prefix,$wpdb;
 
 
	  // Get IP address
  if( ($remote_addr = $_SERVER['REMOTE_ADDR']) == '') {
	$remote_addr = "REMOTE_ADDR_UNKNOWN";
  }
 
  // Get requested script
  if( ($request_uri = $_SERVER['REQUEST_URI']) == '') {
	$request_uri = "REQUEST_URI_UNKNOWN";
  }
  // Get requested script
  if( ($server_addr = $_SERVER['SERVER_ADDR']) == '') {
	$server_addr = "SERVER_ADDR_UNKNOWN";
  }
  // Get requested script
  if( ($user_agent = $_SERVER['HTTP_USER_AGENT']) == '') {
	$user_agent = "HTTP_USER_AGENT_UNKNOWN";
  }
 $message="";

  $message     = $wpdb->_escape($message);
  $remote_addr = $wpdb->_escape($remote_addr);
  $request_uri = $wpdb->_escape($request_uri);
  $server_addr = $wpdb->_escape($server_addr);
  $user_agent = $wpdb->_escape($user_agent);
 
  // Construct query
  $sql = "INSERT INTO ".$table_prefix."ip_log (remote_addr, request_uri, server_addr, user_agent, message) VALUES('$remote_addr', '$request_uri', '$server_addr','$user_agent','$message')";
 
 $wpdb->query($sql);
	
}

add_action( 'wp_enqueue_scripts', 'log_scripts' );
 